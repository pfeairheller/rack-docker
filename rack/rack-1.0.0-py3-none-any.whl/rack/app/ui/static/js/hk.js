function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

async function loadWitnessAuthenticate(eid, oobi, name, cid) {
    const authData = await authenticateWitness(eid, oobi, name, cid)
    let secret = htmx.find("#secret");
    let button = htmx.find("#secretButton")
    let icon = htmx.find("#visibility")
    secret.value = authData.otpurl
    button.addEventListener("click", function () {
        secret.type === "password" ? secret.type = "text" : secret.type = "password";
        icon.innerText === "visibility" ? icon.innerText = "visibility_off" : icon.innerText = "visibility"
    })
    let code = htmx.find("#authentication_code");
    htmx.toggleClass(code, "invisible");

    new QRCode(document.getElementById('qr'), {
        text: authData.otpurl,
        width: 128,
        height: 128,
        colorDark: '#000',
        colorLight: '#fff',
        correctLevel: QRCode.CorrectLevel.M
    });

    let pacifier = htmx.find("#pacifier");
    htmx.toggleClass(pacifier, "hidden");
}

function register_authentication() {
    // confirm event occurs before an HTMX request is issued
    document.body.addEventListener('htmx:confirm', async function (evt) {
        evt.preventDefault();
        const requestDetails = {
            url: evt.detail.path.split("?")[0],
            method: evt.detail.verb.toUpperCase(),
        }
        try {
            // Unlike configRequest, confirm will wait until promises are resolved before allowing the request to be sent. This occurs before configRequest.
            const signedHeaders = await getSignedHeadersFromExtension(requestDetails);
            // Request headers cannot be modified from confirm events; signed headers must be passed to the configRequest event via the detail.elt field, which is common to both of them
            if (Object.keys(signedHeaders).length > 0) {
                evt.detail.elt.signedHeaders = signedHeaders;
                evt.detail.elt.path = requestDetails['url']
                evt.detail.issueRequest();
            }
        } catch (error) {
            console.error("Error getting signed headers from extension")
        }

    });
    // Must be used in tandem with confirm event as configRequest will not wait for async methods, while confirm will not allow access to headers
    document.body.addEventListener('htmx:configRequest', function (evt) {
        const accountAid = getCookie('AID'); // Get aid from cookie
        if (accountAid) {
            evt.detail.headers['AID'] = accountAid; // Set AID header dynamically
        }

        const signedHeaders = evt.detail.elt.signedHeaders;
        if (signedHeaders) {
            // Add the signed headers to the request headers
            for (const [key, value] of Object.entries(signedHeaders)) {
                evt.detail.headers[key] = value;
            }
            evt.detail.headers['method'] = evt.detail.verb;
            evt.detail.headers['path'] = evt.detail.elt.path;
            // Clean up by removing the signed headers from the element
            delete evt.detail.elt.signedHeaders;
        }
    });
}

// Communicate with the browser extension through window events to get signed headers
function getSignedHeadersFromExtension(requestDetails) {
    return new Promise((resolve, reject) => {
        // Unique ID for the request
        const requestId = 'request-' + Date.now() + '-' + Math.random();

        // Handles response event from extension
        function handleResponse(event) {
            if (event.detail && event.detail.requestId === requestId) {
                clearTimeout(timeoutId); // Clear the timeout if response is received
                window.removeEventListener('signRequestResponse', handleResponse);
                const response = event.detail;
                if (response.error) {
                    reject(response.error);
                } else {
                    resolve(response.signedHeaders);
                }
            }
        }

        // Listen for the response event from the extension
        window.addEventListener('signRequestResponse', handleResponse);

        // Dispatch event to request signed headers
        window.dispatchEvent(new CustomEvent('signRequest', {detail: {requestId, requestDetails}}));

        // Timeout rejects the promise if no response is received within x seconds (unnecessary?)
        const timeoutId = setTimeout(() => {
            window.removeEventListener('signRequestResponse', handleResponse);
            reject(new Error('Timeout waiting for signed headers'));
        }, 5000);
    });
}

function authenticateWitness(eid, oobi, name, cid) {
    return new Promise((resolve, reject) => {

        // Unique ID for the request
        const requestId = 'request-' + Date.now() + '-' + Math.random();

        // Handles response event from extension
        function handleResponse(event) {
            if (event.detail && event.detail.requestId === requestId) {
                clearTimeout(timeoutId); // Clear the timeout if response is received
                window.removeEventListener('authenticateWitnessResponse', handleResponse);
                const response = event.detail;
                if (response.error) {
                    reject(response.error);
                } else {
                    resolve(response.response);
                }
            }
        }

        // Listen for the response event from the extension
        window.addEventListener('authenticateWitnessResponse', handleResponse);

        const requestDetails = {
            eid: eid,
            oobi: oobi,
            name: name,
            cid: cid,
        }
        // Dispatch event to request signed headers
        window.dispatchEvent(new CustomEvent('authenticateWitness', {detail: {requestId, requestDetails}}));

        // Timeout rejects the promise if no response is received within x seconds (unnecessary?)
        const timeoutId = setTimeout(() => {
            window.removeEventListener('authenticateWitnessResponse', handleResponse);
            reject(new Error('Timeout waiting for witness authentication'));
        }, 10000);
    });
}

function copyToClipboard(copyText, msg) {
    // Copy the text inside the text field to the clipboard
    navigator.clipboard.writeText(copyText).then(function () {
        alert(msg);
    }).catch(function (error) {
        alert("Failed to copy to clipboard: " + error);
    });
}

function activateTab(tab) {
    document.querySelectorAll('.tab-link').forEach(function (tabLink) {
        if (tabLink.getAttribute('id') === tab) {
            tabLink.classList.add('hk-selected-tab', 'text-gray-900', 'font-semibold');
            tabLink.classList.remove('text-gray-700');
        } else {
            tabLink.classList.remove('hk-selected-tab', 'text-gray-900', 'font-semibold');
            tabLink.classList.add('text-gray-700');
        }
    });
}

function activateDID() {
    let oobi = document.getElementById('oobi');
    oobi.addEventListener('change', function () {
        let did = document.getElementById('did')
            if (oobi.value === "") {
                did.setAttribute("disabled", "true")
            } else {
                did.removeAttribute("disabled")
            }
    })
}
